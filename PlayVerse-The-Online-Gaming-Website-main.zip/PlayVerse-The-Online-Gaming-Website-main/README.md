<div align="center">
  
## :joystick: PlayVerse: The Online Gaming Website
<br>
</div>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PlayVerse is an online gaming website where users can play games online for free. This website aims to provide a fun and engaging platform for gamers to discover and enjoy new games. It will host a wide variety of games, including puzzle games, action games, sports games, strategy games, and more. The user interface of our website is user-friendly. The site will be accessible from the desktop, enabling users to play games anytime and anywhere.<br><br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The primary objective of this project is to create a website that offers a seamless gaming experience and encourages user engagement. PlayVerse is designed with keeping user experience in mind, ensuring that players can easily find and play their favourite games while enjoying a visually appealing and intuitive interface. 

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Playerse contins the database for login, signup and admin. This project also contains the admin page for the developer where he/she can view the user details, game details, number of users, number of games, and also add game details to the database. The developer can also view th conntact form messages and other details.

<div align="center">
  
## 📋 Steps to import database
<br>
</div>

* Step 1 - Open your database in phpMyAdmin.
* Step 2 - Click Databases in the top-menu.
* Step 3 - Create Database named tms.
* Step 4 - Click on Import tab.
* Step 5 - Choose File and click Go.
* Step 6 - You're done.

<div align="center">
  
## 🔐 I'd Password
<br>
</div>

I'd and Password for the Admin login is as follows<br>

* I'd= admin<br>
* Password= admin<br>

<div align="center">
  
## 🖼️ Website Images
<br>

<img src="https://github.com/sarthak0030/PlayVerse-The-Online-Gaming-Website/assets/110853665/950c2c8c-898a-45cd-bc46-ecfb7efd631a" width="550"><br>
  *PlayVerse Website*<br><br><br>
<img src="https://github.com/sarthak0030/PlayVerse-The-Online-Gaming-Website/assets/110853665/99d17a60-3044-4fc4-9dad-48394ab7f76d" width="550"><br>
  *PlayVerse- Admin Page*<br><br><br>
<img src="https://github.com/sarthak0030/PlayVerse-The-Online-Gaming-Website/assets/110853665/2d91af60-e5f2-48cc-ace5-d3a0844873d2" width="550"><br>
  *Memoria: The Memory Game**<br><br><br>
<img src="https://github.com/sarthak0030/PlayVerse-The-Online-Gaming-Website/assets/110853665/c0e65d79-9e56-40eb-9e4f-9e79b3aff568" width="550"><br>
  *Hangman: The Word Game**<br><br><br>
<img src="https://github.com/sarthak0030/PlayVerse-The-Online-Gaming-Website/assets/110853665/f5cecd30-da4c-41cc-b8e3-d7494219ea1a" width="550"><br>
  *Rock-Paper-Scissor**<br><br><br>
<img src="https://github.com/sarthak0030/PlayVerse-The-Online-Gaming-Website/assets/110853665/0543d574-5c21-4119-89e7-2a6104185f58" width="550"><br>
  *Tic-Tac-Toe**<br><br><br>
<img src="https://github.com/sarthak0030/PlayVerse-The-Online-Gaming-Website/assets/110853665/2b11c6b0-3b2a-4a09-829b-635b1666de44" width="550"><br>
  *Connect 4**<br>

</div>

<div align="center">
  
## 👀 About Me
<br>
</div>

   * 🏫 I am a second year BCA student at Ashoka Center for Business and Computer Studies
   * 👨‍💻 I'm currently working on my hacking skills
   * 👾 Outside the world of tech. I love pushing myself to develop new skills rainging from basketball, sketching all the way to learning new computer languages
   * 🏀 I love playing baskeball as it improves my concentration power, increases my team work ability and helps me to tackle new problems
   * 📫 How to reach me patilsarthak00030@gmail.com
   * 💬 Ask me about anything, I will be happy to help
 
<div align="center">

## 🌐 Socials
<br>

   [![github](https://img.shields.io/badge/github-000000?style=for-the-badge&logo=github&logoColor=white)](https://www.github.com/sarthak0030/)
   [![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/sarthak-patil30)
   [![instagram](https://img.shields.io/badge/instagram-e6005c?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/sarthak._.patil30)
   [![e-mail](https://img.shields.io/badge/email-f84437?style=for-the-badge&logo=gmail&logoColor=white)](mailto:patilsarthak00030@gmail.com)
<br><br>
</div>

\* The following Games are made with referance to [codingartistweb.com](https://codingartistweb.com/), we do not own the copyrights of the game.
